﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using Sokoban;
using System.Windows.Forms;
using Utilitaires;
using System.IO;
using System.Linq;
using System.Threading;
using System.Diagnostics;

namespace AffichageGame
{

    public partial class AffichageGraphique : Form
    {
        public static Map mapActuel;
        public static int lv;

        public AffichageGraphique(Map map, int level)
        {
            InitializeComponent();
            lv = level;
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.White;
            AffichageGraphique.mapActuel = map;
            button1.Enabled = false;
            this.KeyPreview = true;
            this.Afficher(map);
            listBox1.SelectedIndex = lv - 1;
        }
        

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Map x = new Map();
            x = mapActuel.Clone() as Map;
            mapActuel = Map.OnMove(mapActuel, char.Parse(e.KeyChar.ToString()));
            
            this.Afficher2(x);

            if (Map.Win(x))
            {
                string path = Resource.File;
                string cd = Directory.GetCurrentDirectory();
                DirectoryInfo di = new DirectoryInfo(cd);
                di = di.Parent.Parent.Parent.Parent;

                MessageBox.Show($"OUHOUHOUH You Have Win The Gameeeee!!!!!!\nNombre de coup joués {Caisse.nbMouvement.ToString()}");
                lv++;
                listBox1.SelectedIndex = lv-1;
                Caisse.nbMouvement = 0;
                Map map = new Map();
                AffichageGraphique.mapActuel = map.GetMapInit(di + "/" + path, lv);
                this.Afficher(map);
            }
        }
        public void Afficher(Map map)
        {
            string path = Resource.File;
            string cd = Directory.GetCurrentDirectory();
            DirectoryInfo di = new DirectoryInfo(cd);
            di = di.Parent.Parent.Parent.Parent;

            reset();
            int c = 0;
            for (int i = 0; i < map.Count; i++)
            {
                if (i % map.Taille == 0 && i != 0) c++;
                int x = i - (mapActuel.Taille * c);
                PictureBox bouton = new PictureBox();
                bouton.Size = new Size(50, 50);
                if (map[i] is Personnage)
                {
                    bouton.Name = "p";
                    Image image = Image.FromFile(di + "/personnage.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }

                else if (map[i] is Caisse)
                {
                    Image image = Image.FromFile(di + "/trophy.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else if (map[i] is Mur)
                {
                    Image image = Image.FromFile(di + "/cactus.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else if (map[i] is Emplacement)
                {
                    Image image = Image.FromFile(di + "/terre.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                //else { bouton.BackColor = Color.SaddleBrown; }
                bouton.Location = new Point(x * 50, c * 50);
                Controls.Add(bouton);
                
            }
        }
       /* public void Afficher3(Map map)
        {
            string path = Resource.File;
            string cd = Directory.GetCurrentDirectory();
            DirectoryInfo di = new DirectoryInfo(cd);
            di = di.Parent.Parent.Parent.Parent;

            foreach (Elements elem in map)
            {
                PictureBox bouton = new PictureBox(); /// <-- c'est quoi ce bordel
                bouton.Size = new Size(50, 50);

                if (elem is Personnage)
                {
                    bouton.Name = "p";
                    Image image = Image.FromFile(di + "/personnage.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else if (elem is Mur)
                {
                    Image image = Image.FromFile(di + "/cactus.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else if (elem is Caisse)
                {
                    Image image = Image.FromFile(di + "/trophy.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else if (elem is Emplacement)
                {
                    Image image = Image.FromFile(di + "/terre.png");
                    image = new Bitmap(image, 50, 50);
                    bouton.Image = image;
                }
                else
                {
                    bouton.BackColor = Color.SaddleBrown;
                }
                bouton.Location = new Point(elem.Y * 50, elem.X * 50);
                Controls.Add(bouton);
            }        
        }*/
       public void Afficher2(Map map)
        {
            string path = Resource.File;
            string cd = Directory.GetCurrentDirectory();
            DirectoryInfo di = new DirectoryInfo(cd);
            di = di.Parent.Parent.Parent.Parent;

            int c = 0;
            for (int i = 0; i < map.Count; i++)
            {
                if (i % map.Taille == 0 && i != 0) c++;
                int x = i - (map.Taille * c);

                if (map[i] != mapActuel[i])
                {
                    Controls.Remove(GetChildAtPoint(new Point(x * 50, c * 50)));
                    PictureBox bouton = new PictureBox(); /// <-- c'est quoi ce bordel
                    bouton.Size = new Size(50, 50);
                    if (mapActuel[i] is Personnage)
                    {
                        bouton.Name = "p";
                        Image image = Image.FromFile(di + "/personnage.png");
                        image = new Bitmap(image, 50, 50);
                        bouton.Image = image;
                    }
                    else if (mapActuel[i] is Caisse)
                    {
                        Image image = Image.FromFile(di + "/trophy.png");
                        image = new Bitmap(image, 50, 50);
                        bouton.Image = image;
                    }
                    else if (mapActuel[i] is Emplacement)
                    {
                        Image image = Image.FromFile(di + "/terre.png");
                        image = new Bitmap(image, 50, 50);
                        bouton.Image = image;
                    }
                    //else { bouton.BackColor = Color.SaddleBrown; }
                    bouton.Location = new Point(x * 50, c * 50);
                    Controls.Add(bouton);
                }
            }
        }

        /*public void Afficher4(Map map)
        {
            for (int i = 0; i < map.Count; i++)
            {
                if (map[i].Y != mapActuel[i].Y || map[i].X != mapActuel[i].X)
                {
                    GetChildAtPoint(new Point(mapActuel[i].Y * 50, mapActuel[i].X * 50)).Location = new Point(map[i].Y, map[i].X);
                }
            }
        }*/

        private void AffichageGraphique_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = Resource.File;
            string cd = Directory.GetCurrentDirectory();
            DirectoryInfo di = new DirectoryInfo(cd);
            di = di.Parent.Parent.Parent.Parent;

            string level = listBox1.SelectedItem.ToString();


            Map map = new Map();
            AffichageGraphique.mapActuel = map.GetMapInit(di + "/" + path, int.Parse(level));
            this.Afficher(map);
        }


        #region reset
        /// <summary>
        /// Reset Map
        /// </summary>
        private void reset()
        {
            for (int i = 0; i < 12; i++)
            {
                foreach (var item in Controls)
                {
                    if (item is PictureBox p) Controls.Remove(p);

                }
            }
        }
        #endregion reset
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }
    }
}
