﻿using System;

namespace Sokoban
{
    public class Emplacement : Elements
    {
        #region Champs privés
        #endregion Champs privés

        #region propriétés 

        #endregion propriétés 

        #region Méthode

        #endregion Méthode

        #region Constructeur
        public Emplacement(int x, int y) : base(x, y)
        {
            Content = '.';
        }
        #endregion Constructeur

        #region Evenement
        #endregion Evenement

    }


}
