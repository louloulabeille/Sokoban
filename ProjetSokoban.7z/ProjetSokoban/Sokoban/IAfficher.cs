﻿using Sokoban;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Utilitaires
{
    public interface IAfficher
    {
        void Afficher(Map map);
    }
}
