﻿namespace Sokoban
{
    public class Mur : Elements
    {
        #region Champs privés
        #endregion Champs privés

        #region propriétés 
        #endregion propriétés 

        #region Méthode
        #endregion Méthode

        #region Constructeur
        public Mur(int x, int y) : base(x, y)
        {
            Content = 'X';
        }
        #endregion Constructeur

        #region Evenement
        #endregion Evenement

    }


}
